# Portfólio — Luís Fernando

Portfólio pessoal com chatbot de IA integrado, construído com Next.js 14 (App Router).

---

## Tecnologias usadas

- **Next.js 14** (App Router + TypeScript)
- **Anthropic SDK** (claude-sonnet-4)
- **CSS puro** (sem Tailwind — tudo em globals.css)
- **Google Fonts** (Syne + DM Sans + DM Mono)

---

## Como rodar localmente

### 1. Instale as dependências

```bash
npm install
```

### 2. Configure a chave da API

Copie o arquivo de exemplo e preencha com sua chave:

```bash
cp .env.example .env.local
```

Edite o `.env.local`:

```
ANTHROPIC_API_KEY=sk-ant-SUA_CHAVE_AQUI
```

Para obter a chave: https://console.anthropic.com

### 3. Rode o servidor de desenvolvimento

```bash
npm run dev
```

Acesse: http://localhost:3000

---

## Como fazer deploy no Vercel

1. Suba o projeto para o GitHub (certifique-se de que `.env.local` está no `.gitignore`)
2. Importe o repositório no Vercel: https://vercel.com/new
3. Na tela de configuração, vá em **Environment Variables**
4. Adicione: `ANTHROPIC_API_KEY` = `sk-ant-SUA_CHAVE_AQUI`
5. Clique em **Deploy**

---

## Estrutura do projeto

```
app/
  layout.tsx          → Layout raiz (metadados, fonte)
  page.tsx            → Página principal (hero + navegação + seções)
  globals.css         → Todo o CSS do site
  api/
    chat/
      route.ts        → API route do chatbot (backend seguro)

components/
  ChatBot.tsx         → Chatbot com histórico e sugestões
  Projects.tsx        → Seção de projetos
  About.tsx           → Sobre + timeline + skills
  Skills.tsx          → Barras de habilidades
```

---

## Personalizar o chatbot

Para atualizar o que a IA sabe sobre você, edite o arquivo:

```
app/api/chat/route.ts
```

Altere a constante `SYSTEM` com suas novas informações.

---

## Instalar o Anthropic SDK (caso não esteja instalado)

```bash
npm install @anthropic-ai/sdk
```
